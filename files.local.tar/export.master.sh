#!/bin/sh

TMPDIR=/home/tmp.export

WD=$('/bin/pwd')

/usr/local/bin/git clone https://github.com/cliffanet/manifest.git $TMPDIR \
    && cd $TMPDIR \
    && /usr/local/bin/git checkout master \
    && date > ver.txt \
    && /usr/local/bin/git show --name-only master >> ver.txt \
    && cd $WD \
    && /bin/rm -rf $TMPDIR/.git \
    && /usr/bin/find /home/manifest/ -name "*" -type f -print | egrep -vf "/home/manifest/.exclude.txt" | /usr/bin/xargs rm -f \
    && /usr/bin/find /home/manifest/ -name "*" -type l -print | egrep -vf "/home/manifest/.exclude.txt" | /usr/bin/xargs rm -f \
    && /usr/bin/find /home/manifest/ -name "*" -type d -d -print | egrep -vf "/home/manifest/.exclude.txt" | /usr/bin/xargs rmdir \
    && cp -a $TMPDIR/ /home/manifest \
    && /bin/rm -rf $TMPDIR \
    || exit


/usr/local/bin/git clone --branch master https://github.com/cliffanet/Clib.git $TMPDIR \
    && /bin/rm -rf $TMPDIR/.git \
    && /bin/rm -rf /home/Clib \
    && /bin/mv -v $TMPDIR /home/Clib \
    || exit

/usr/local/etc/rc.d/manifest.main.fcgi restart
